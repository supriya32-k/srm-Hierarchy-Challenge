import express from "express";
import cors from "cors";
import path from "path";
import { createServer as createViteServer } from "vite";

const app = express();
app.use(cors());
app.use(express.json());

const PORT = 3000;

// Algorithm for processing hierarchies
function processHierarchies(data: string[]) {
  const validEdges: { p: string; c: string }[] = [];
  const invalid_entries: string[] = [];
  const duplicate_edges: Set<string> = new Set();
  const seenPairs: Set<string> = new Set();

  // 1. Validate and filter edges
  data.forEach((entry) => {
    const trimmed = entry.trim();
    if (!trimmed) {
      invalid_entries.push(entry);
      return;
    }

    // Pattern: X->Y (exactly 4 chars if no spaces, but we should be robust)
    // Actually rule says X and Y are each a single uppercase letter
    const parts = trimmed.split("->");
    if (parts.length !== 2) {
      invalid_entries.push(entry);
      return;
    }

    const p = parts[0].trim();
    const c = parts[1].trim();

    const isUppercaseLetter = (s: string) => /^[A-Z]$/.test(s);

    if (!isUppercaseLetter(p) || !isUppercaseLetter(c) || p === c) {
      invalid_entries.push(entry);
      return;
    }

    const pair = `${p}->${c}`;
    if (seenPairs.has(pair)) {
      duplicate_edges.add(pair);
    } else {
      seenPairs.add(pair);
      validEdges.push({ p, c });
    }
  });

  // 2. Build adjacency list while respecting "first parent wins"
  const adj: Map<string, string[]> = new Map();
  const parentMap: Map<string, string> = new Map();
  const allNodes: Set<string> = new Set();

  validEdges.forEach(({ p, c }) => {
    allNodes.add(p);
    allNodes.add(c);
    
    // First parent wins: if c already has a parent, ignore this edge
    if (!parentMap.has(c)) {
      parentMap.set(c, p);
      if (!adj.has(p)) adj.set(p, []);
      adj.get(p)!.push(c);
    }
  });

  // 3. Group nodes into components (weakly connected)
  const visited = new Set<string>();
  const components: string[][] = [];

  // Build undirected adjacency for component finding
  const undirAdj: Map<string, string[]> = new Map();
  allNodes.forEach(node => undirAdj.set(node, []));
  validEdges.forEach(({ p, c }) => {
    // Only use edges that were actually added to our directed graph (respecting first parent wins)
    if (parentMap.get(c) === p) {
      undirAdj.get(p)!.push(c);
      undirAdj.get(c)!.push(p);
    }
  });

  allNodes.forEach((node) => {
    if (!visited.has(node)) {
      const comp: string[] = [];
      const stack = [node];
      visited.add(node);
      while (stack.length > 0) {
        const u = stack.pop()!;
        comp.push(u);
        (undirAdj.get(u) || []).forEach((v) => {
          if (!visited.has(v)) {
            visited.add(v);
            stack.push(v);
          }
        });
      }
      components.push(comp);
    }
  });

  // 4. Process each component
  const hierarchies: any[] = [];
  let total_trees = 0;
  let total_cycles = 0;
  let maxDepth = -1;
  let largest_tree_root = "";

  components.forEach((comp) => {
    // Find roots in this component
    const roots = comp.filter(node => !parentMap.has(node)).sort();
    
    let root = "";
    let isCycle = false;

    if (roots.length > 0) {
      root = roots[0]; // first root
    } else {
      // Pure cycle
      root = comp.sort()[0]; // lexicographically smallest
      isCycle = true;
    }

    if (isCycle) {
      total_cycles++;
      hierarchies.push({
        root,
        tree: {},
        has_cycle: true
      });
    } else {
      // Build tree structure and calculate depth
      const buildTree = (u: string): any => {
        const children = adj.get(u) || [];
        const treeObj: any = {};
        children.sort().forEach(v => {
          treeObj[v] = buildTree(v);
        });
        return treeObj;
      };

      const getDepth = (u: string): number => {
        const children = adj.get(u) || [];
        if (children.length === 0) return 1;
        return 1 + Math.max(...children.map(getDepth));
      };

      const depth = getDepth(root);
      const tree = { [root]: buildTree(root) };
      
      hierarchies.push({
        root,
        tree,
        depth
      });

      total_trees++;
      if (depth > maxDepth) {
        maxDepth = depth;
        largest_tree_root = root;
      } else if (depth === maxDepth) {
        if (!largest_tree_root || root < largest_tree_root) {
          largest_tree_root = root;
        }
      }
    }
  });

  return {
    user_id: "dattasupriya_kamireddy_24042026", // Format: "fullname_ddmmyyyy"
    email_id: "dattasupriya_kamireddy@srmap.edu.in",
    college_roll_number: "AP23110010648", // Updated roll number
    hierarchies,
    invalid_entries,
    duplicate_edges: Array.from(duplicate_edges),
    summary: {
      total_trees,
      total_cycles,
      largest_tree_root
    }
  };
}

app.post("/bfhl", (req, res) => {
  const { data } = req.body;
  if (!Array.isArray(data)) {
    return res.status(400).json({ error: "Invalid request body. 'data' must be an array." });
  }

  try {
    const result = processHierarchies(data);
    res.json(result);
  } catch (error) {
    console.error("Processing error:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});

app.get("/bfhl", (req, res) => {
  res.status(200).json({ operation_code: 1 });
});

async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
