import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Send, 
  AlertCircle, 
  CheckCircle2, 
  ChevronRight, 
  ChevronDown, 
  TreePine, 
  RefreshCcw, 
  Info,
  Layers,
  Database
} from "lucide-react";

interface Hierarchy {
  root: string;
  tree: any;
  depth?: number;
  has_cycle?: boolean;
}

interface ApiResponse {
  user_id: string;
  email_id: string;
  college_roll_number: string;
  hierarchies: Hierarchy[];
  invalid_entries: string[];
  duplicate_edges: string[];
  summary: {
    total_trees: number;
    total_cycles: number;
    largest_tree_root: string;
  };
}

const TreeView = ({ data, level = 0 }: { data: any; level?: number }) => {
  const [isOpen, setIsOpen] = useState(true);

  if (typeof data !== "object" || data === null || Object.keys(data).length === 0) {
    return null;
  }

  return (
    <div className={`ml-${level > 0 ? "6" : "0"} mt-1`}>
      {Object.entries(data).map(([key, children]) => {
        const hasChildren = children && typeof children === "object" && Object.keys(children).length > 0;
        return (
          <div key={key} className="group">
            <div 
              className={`flex items-center space-x-2 py-1 px-2 rounded-md transition-colors ${
                hasChildren ? "hover:bg-gray-100 cursor-pointer" : "hover:bg-gray-50"
              }`}
              onClick={() => hasChildren && setIsOpen(!isOpen)}
            >
              {hasChildren ? (
                isOpen ? <ChevronDown size={14} className="text-gray-400" /> : <ChevronRight size={14} className="text-gray-400" />
              ) : (
                <div className="w-[14px]" />
              )}
              <div className="flex items-center space-x-2">
                <span className="w-8 h-8 flex items-center justify-center bg-blue-50 text-blue-600 rounded-full font-bold text-sm border border-blue-100 shadow-sm">
                  {key}
                </span>
                {hasChildren && (
                  <span className="text-xs text-gray-400 font-medium">
                    ({Object.keys(children as object).length} sub-nodes)
                  </span>
                )}
              </div>
            </div>
            {hasChildren && isOpen && (
              <div className="border-l-2 border-gray-100 ml-4 pl-2">
                <TreeView data={children} level={level + 1} />
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
};

export default function App() {
  const [input, setInput] = useState('["A->B", "A->C", "B->D", "B->E", "X->Y", "Y->Z", "Z->X"]');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<ApiResponse | null>(null);
  const [showRawJson, setShowRawJson] = useState(false);

  const handleSubmit = async () => {
    setLoading(true);
    setError(null);
    try {
      let data;
      try {
        data = JSON.parse(input);
      } catch (e) {
        throw new Error("Invalid format. Please provide a valid JSON array of strings.");
      }

      if (!Array.isArray(data)) {
        throw new Error("Input must be a JSON array.");
      }

      const response = await fetch("/bfhl", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ data }),
      });

      if (!response.ok) {
        throw new Error(`API failed with status ${response.status}`);
      }

      const json = await response.json();
      setResult(json);
    } catch (err: any) {
      setError(err.message || "An unexpected error occurred");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-neutral-50 font-sans text-neutral-900 selection:bg-blue-100">
      {/* Header */}
      <header className="bg-white border-b border-neutral-200 sticky top-0 z-50">
        <div className="max-w-5xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center shadow-lg shadow-blue-200">
              <Layers className="text-white" size={24} />
            </div>
            <h1 className="text-xl font-bold tracking-tight text-neutral-800">
              Hierarchy <span className="text-blue-600">Engine</span>
            </h1>
          </div>
          <div className="flex items-center space-x-4">
            <div className="hidden sm:flex flex-col items-end text-xs font-medium">
               <span className="text-neutral-800">Dattasupriya Kamireddy</span>
               <span className="text-neutral-400">AP23110010648</span>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-4 py-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            {/* Input Section */}
            <div className="lg:col-span-5 space-y-6">
              <div className="bg-white p-6 rounded-2xl shadow-sm border border-neutral-200">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center space-x-2">
                    <Database size={18} className="text-blue-500" />
                    <h2 className="font-semibold text-neutral-700">Input Data</h2>
                  </div>
                  <button 
                    onClick={() => setInput('["A->B", "A->C", "B->D", "C->E", "X->Y", "Y->Z", "Z->X", "hello"]')}
                    className="text-[10px] font-bold text-blue-600 hover:text-blue-700 bg-blue-50 px-2 py-1 rounded border border-blue-100 transition-colors"
                  >
                    LOAD SAMPLE
                  </button>
                </div>
                <p className="text-sm text-neutral-500 mb-4">
                  Enter a JSON array of node strings following the "X-&gt;Y" format.
                </p>
                <textarea
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  className="w-full h-48 p-4 bg-neutral-50 border border-neutral-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all font-mono text-sm resize-none"
                  placeholder='["A->B", "C->D"]'
                />
                <button
                  onClick={handleSubmit}
                  disabled={loading}
                  className="w-full mt-4 bg-blue-600 hover:bg-blue-700 disabled:bg-blue-300 text-white font-semibold py-3 rounded-xl transition-all flex items-center justify-center space-x-2 shadow-md shadow-blue-100 active:scale-[0.98]"
                >
                  {loading ? (
                    <>
                      <RefreshCcw className="animate-spin" size={20} />
                      <span>Processing...</span>
                    </>
                  ) : (
                    <>
                      <Send size={18} />
                      <span>Process Hierarchies</span>
                    </>
                  )}
                </button>
              </div>

              {error && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="bg-red-50 border border-red-100 p-4 rounded-xl flex items-start space-x-3"
                >
                  <AlertCircle className="text-red-500 shrink-0" size={20} />
                  <span className="text-sm text-red-700 font-medium">{error}</span>
                </motion.div>
              )}

              <div className="bg-blue-50/50 p-4 rounded-xl border border-blue-100/50 space-y-3">
                <div className="flex items-center space-x-2 text-blue-700 font-semibold text-sm">
                  <Info size={16} />
                  <span>Rules</span>
                </div>
                <ul className="text-xs text-blue-600 space-y-1 opacity-80 list-disc ml-4">
                  <li>Valid format: Single uppercase letter parent and child (e.g., A-&gt;B).</li>
                  <li>First encountered parent wins for multi-parent nodes.</li>
                  <li>Automatic cycle detection and component grouping.</li>
                  <li>Duplicate edges are filtered and reported.</li>
                </ul>
              </div>
            </div>

            {/* Results Section */}
            <div className="lg:col-span-7">
              <AnimatePresence mode="wait">
                {!result && !loading && (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="h-full flex flex-col items-center justify-center p-12 bg-white rounded-2xl border-2 border-dashed border-neutral-200 text-neutral-400"
                  >
                    <TreePine size={48} className="mb-4 opacity-20" />
                    <p className="text-sm font-medium">Ready to process your nodes.</p>
                  </motion.div>
                )}

                {result && (
                  <motion.div
                    key="results"
                    initial={{ opacity: 0, scale: 0.98 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="space-y-6"
                  >
                    {/* Summary Cards */}
                    <div className="grid grid-cols-3 gap-4">
                      <div className="bg-white p-4 rounded-2xl border border-neutral-200 shadow-sm text-center">
                        <div className="text-xs font-bold text-neutral-400 uppercase tracking-wider mb-1">Total Trees</div>
                        <div className="text-2xl font-black text-blue-600">{result.summary.total_trees}</div>
                      </div>
                      <div className="bg-white p-4 rounded-2xl border border-neutral-200 shadow-sm text-center">
                        <div className="text-xs font-bold text-neutral-400 uppercase tracking-wider mb-1">Total Cycles</div>
                        <div className="text-2xl font-black text-amber-600">{result.summary.total_cycles}</div>
                      </div>
                      <div className="bg-white p-4 rounded-2xl border border-neutral-200 shadow-sm text-center">
                        <div className="text-xs font-bold text-neutral-400 uppercase tracking-wider mb-1">Largest Tree</div>
                        <div className="text-2xl font-black text-green-600">{result.summary.largest_tree_root || "N/A"}</div>
                      </div>
                    </div>

                    {/* Hierarchies */}
                    <div className="bg-white rounded-2xl border border-neutral-200 shadow-sm overflow-hidden">
                      <div className="px-6 py-4 border-b border-neutral-100 bg-neutral-50/50 flex justify-between items-center">
                        <h3 className="font-bold text-neutral-700 flex items-center space-x-2">
                          <CheckCircle2 size={18} className="text-green-500" />
                          <span>Discovered Hierarchies</span>
                        </h3>
                        <span className="bg-neutral-200 text-neutral-600 text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-tight">
                          {result.hierarchies.length} groups
                        </span>
                      </div>
                      <div className="p-6 space-y-8 max-h-[600px] overflow-y-auto">
                        {result.hierarchies.map((h, i) => (
                          <div key={i} className="space-y-4">
                            <div className="flex items-center space-x-3">
                              <span className="text-xs font-black text-neutral-300 uppercase">Group {i + 1}</span>
                              <div className="h-px flex-1 bg-neutral-100"></div>
                              {h.has_cycle && (
                                <span className="text-[10px] font-bold bg-amber-100 text-amber-700 px-2 py-0.5 rounded-full">CYCLE DETECTED</span>
                              )}
                              {h.depth && (
                                <span className="text-[10px] font-bold bg-blue-100 text-blue-700 px-2 py-0.5 rounded-full">DEPTH: {h.depth}</span>
                              )}
                            </div>
                            <div className="p-4 bg-neutral-50 rounded-xl border border-neutral-100">
                              {h.has_cycle ? (
                                <div className="flex items-center space-x-2 text-amber-600 italic text-sm">
                                  <AlertCircle size={14} />
                                  <span>No tree structure available for cyclic paths from {h.root}.</span>
                                </div>
                              ) : (
                                <TreeView data={h.tree} />
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Metadata & Errors */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      {result.invalid_entries.length > 0 && (
                        <div className="bg-white p-6 rounded-2xl border border-red-100 shadow-sm transition-all hover:shadow-md">
                          <div className="flex justify-between items-center mb-3">
                            <h4 className="text-xs font-bold text-red-500 uppercase tracking-wider">Invalid Entries</h4>
                            <span className="bg-red-100 text-red-700 text-[10px] font-bold px-2 py-0.5 rounded-full">
                              {result.invalid_entries.length}
                            </span>
                          </div>
                          <div className="flex flex-wrap gap-2">
                            {result.invalid_entries.map((item, idx) => (
                              <span key={idx} className="bg-red-50 text-red-600 text-[10px] font-mono font-bold px-2 py-1 rounded-md border border-red-100 italic">
                                {item || '""'}
                              </span>
                            ))}
                          </div>
                        </div>
                      )}
                      {result.duplicate_edges.length > 0 && (
                        <div className="bg-white p-6 rounded-2xl border border-blue-100 shadow-sm transition-all hover:shadow-md">
                          <div className="flex justify-between items-center mb-3">
                            <h4 className="text-xs font-bold text-blue-500 uppercase tracking-wider">Duplicate Edges</h4>
                            <span className="bg-blue-100 text-blue-700 text-[10px] font-bold px-2 py-0.5 rounded-full">
                              {result.duplicate_edges.length}
                            </span>
                          </div>
                          <div className="flex flex-wrap gap-2">
                            {result.duplicate_edges.map((item, idx) => (
                              <span key={idx} className="bg-blue-50 text-blue-600 text-[10px] font-mono font-bold px-2 py-1 rounded-md border border-blue-100">
                                {item}
                              </span>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Raw JSON View */}
                    <div className="bg-neutral-800 rounded-2xl overflow-hidden shadow-xl">
                      <button 
                        onClick={() => setShowRawJson(!showRawJson)}
                        className="w-full px-6 py-4 flex items-center justify-between text-white/70 hover:text-white transition-colors border-b border-white/10"
                      >
                        <div className="flex items-center space-x-2">
                          <Database size={16} />
                          <span className="text-sm font-bold uppercase tracking-widest">Raw Data Response</span>
                        </div>
                        {showRawJson ? <ChevronDown size={18} /> : <ChevronRight size={18} />}
                      </button>
                      <AnimatePresence>
                        {showRawJson && (
                          <motion.div
                            initial={{ height: 0, opacity: 0 }}
                            animate={{ height: "auto", opacity: 1 }}
                            exit={{ height: 0, opacity: 0 }}
                            className="overflow-hidden"
                          >
                            <div className="p-6">
                              <pre className="text-[11px] font-mono text-blue-300 overflow-x-auto p-4 bg-black/40 rounded-xl border border-white/5 whitespace-pre-wrap">
                                {JSON.stringify(result, null, 2)}
                              </pre>
                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>
      </main>

      <footer className="mt-20 border-t border-neutral-200 bg-white py-12">
        <div className="max-w-5xl mx-auto px-4 flex flex-col md:flex-row justify-between items-center text-sm text-neutral-400">
          <p>© 2026 SRMAP Challenge Implementation</p>
          <div className="mt-4 md:mt-0 flex items-center space-x-6">
            <div className="flex flex-col items-center md:items-end">
              <span className="font-bold text-neutral-600">{result?.email_id || "dattasupriya_kamireddy@srmap.edu.in"}</span>
              <span>{result?.college_roll_number || "AP23110010648"}</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
